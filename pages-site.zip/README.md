# Sites for GitHub Pages

Each site is available at `/<repository>/<tag>/`. The repository root intentionally shows a blank page.

Site folders contain their own `content.json`; shared static assets are in `assets/`.

GitHub Pages cannot write to the repository. Admin edits are saved in the current browser and can be exported as JSON for a later repository update.
